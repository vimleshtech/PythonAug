#input
a=int(input("Enter marks in English : "))
b=int(input("Enter marks in Hindi : "))
c=int(input("Enter marks in Maths : "))
d=int(input("Enter marks in Science : "))
e=int(input("Enter marks in GK : "))

#expression
f=(a+b+c+d+e)/5

#output
print ("Average is : ",f) 
if f>=60:
     print("First Division")
elif f>50:
     print("Second Division")
elif f>40:
     print("Third Division")
else:
     print("Fail")


