#input
a=int(input("Enter value of a: "))
b=int(input("Enter value of b: "))
c=int(input("Enter value of c: "))
d=int(input("Enter value of d: "))

#expression

#e=a*a*a+b*b*b+c*c*c
e=a**3+b**3+c**3
f=d**3

#output

print("value of a^3+b^3+c^3=",e)
print("value of d^3=",f)

if e==f:
     print ("Condition Satisfied")
else:
     print ("Condition NOT Stisfied")
