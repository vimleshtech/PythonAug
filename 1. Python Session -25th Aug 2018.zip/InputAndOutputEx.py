a = input('enter data :')
b = input('enter data :')
name = input('enter name :')

c =int(a) + int(b) # typecast/convert from string to int 
print(c)
print('you have entered :',name)




