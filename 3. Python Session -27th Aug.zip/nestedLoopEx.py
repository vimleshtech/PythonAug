for r in range(1,5): # 1 to 4
     for c in range(1,4): # 1 to 3
          print(c)
          

##shwo in one row
for r in range(1,5): # 1 to 4
     for c in range(1,4): # 1 to 3
          print(c,end='')

#show in tabular format
for r in range(1,5): # 1 to 4
     for c in range(1,4): # 1 to 3
          print(c,end='\t') # in same line 
     print()#new line 


#print pattern
'''
1
12
123
1234
'''
for r in range(1,5): # 1 to 4
     for c in range(1,r+1): # 1 to 3
          print(c,end='\t') # in same line 
     print()#new line 








     
          
          
