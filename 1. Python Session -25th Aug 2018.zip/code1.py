a =1
b =3
c=a+b
print(c)


#data type
a =11 #int
print(type(a))


a =11.3 #float
print(type(a))

a ='11' #str
print(type(a))
a ="11" #str
print(type(a))

a =True #bool
print(type(a))

a =[11,4,4,5,56,6,76] #list
print(type(a))


a =(11,4,4,5,56,6,76) #tuple
print(type(a))


a ={1:'one',11:'eleven','a':'alpha' } #dict
print(type(a))

a ={'dove','lux','dove'}
print(type(a))





