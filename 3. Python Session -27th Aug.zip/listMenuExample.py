emp = [] #declare empty list
while True:
     ch = input('enter 1 for add 2 for show 3 for delete 4 for sort 5 for exit')
     if ch=='1':
          d = int( input('enter data :'))
          emp.append(d)
     elif ch=='2':
          print(emp)
     elif ch=='3':
          d = int( input('enter value to remove :'))
          emp.remove(d)
     elif ch =='4':
          emp.sort()
     elif ch=='5':
          print('you decieded for exit ')
          break
     else:
          print('invalid choice')
     
     
