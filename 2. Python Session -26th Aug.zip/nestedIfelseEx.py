a = int(input('enter no. '))
b = int(input('enter no. '))
c = int(input('enter no. '))

#nested if else 
if a>b: # parent if 
     if a>c: # child / nested / inner if 
          print('a is gt')
     else:
          print('c  is gt')
else:
     if b>c:
          print('b is gt')
     else:
          print('c is gt')

#or: if elif elif else... / ladder if else 
if a>b and a>c:
     print('a is gt')
elif b>a and b>c:
     print('b is gt')
else:
     print('c is gt')
     
