#while loop

i =1 # init
while i<100: # condition
     #print(i)  # print and change the line / new line
     print(i,end=',') # print and don't change the line 
     i = i+1 # incrementer
     
     
##print in reverse order
i =10
while i>0:
     print(i)
     i =i-1
     

#print all odd numbers between 1 to 30
i =1
while i<=30:
     print(i)
     i =i+2
     
#wap to get sum of all even no. and odd no. between 1 to 100
se =0
so =0

i =1
while i<=100:
     if i% 2==0:
          se =se+i
     else:
          so =so+i
     i = i+1

print('sum of all even no :',se)
print('sum of all odd no :',so)

##print table of given no.
t =int(input('enter no. '))
i =1
while i<=10:
     #print(t*i)
     print(t,'*',i,'=',(t*i))
     i =i+1

### for loop
for i in range(1,10):  # from 1 to 9 , and default incrementer is 1
     print(i)


#print in reverese
for d in range(10,0,-1): # from 10 to 1
     print(d)



#print all odd numbers between two range
for i in range(1,30,2):
     print(i)
     





     



     
     




     
          










     



          



