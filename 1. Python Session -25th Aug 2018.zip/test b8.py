#input
a=int(input("Enter salary"))

#Condition

if a>=5000 and a<=10000:
     print("HRA is 10%:",a*.10)
     print("DA is 5%:",a*.05)

elif a>=10001 and a<=15000:
     print("HRA is 15%:",a*.15)
     print("DA is 8%:",a*.08)
