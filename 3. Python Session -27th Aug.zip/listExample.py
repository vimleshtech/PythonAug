a = [11,2,3,4,5]
#print all elements 
print(a)

#access element by index
print(a[1]) #2nd element

#slicer
print(a[0:3])  # 0,1st,2nd element 
print(a[:3])  # 0,1st,2nd element
print(a[2:4])  # 2nd,3rd
print(a[-1])  # last element

#print all element one by one
i =0
while i<len(a):
     print(a[i])
     i =i+1


#using for
for e in a: # read all element one by one 
     print(e)

##append
a.append(100)
print(a)

#pop
a.pop()
print(a)

#insert
a.insert(1,200)
print(a)

#remove
a.remove(2)
print(a)

#sort # arrange in acending order 
a.sort()
print(a)

#print in decending
print(a[::-1])

#max
print(max(a))
print(min(a))
print(sum(a))
print(len(a))




















     

     
     

