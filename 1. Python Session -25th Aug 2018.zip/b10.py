#input
a= int(input("Enter units consumed in a month : "))

#expression




if a<=100:
     
     print("Total bill = ",(a*0.40)+50)
elif a<=300:

     
     print("Total bill = ", 40+(a-100)*.50+50)
else:
    print("Total bill = ", 140+(a-300)*.60+50) 

     #go_kumaranil@yahoo.com

