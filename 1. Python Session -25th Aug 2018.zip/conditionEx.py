#input
sid = input('enter sid :')
sname = input('enter name :')
hs = int( input('enter mark in hindi :'))
es = int( input('enter mark in eng. :'))
cs = int( input('enter mark in computer :'))

#expression
total = hs+es+cs
avg = total/3

#print 
print('student id :' , sid)
print('student name :' , sname)
print('student total score :' , total)
print('student avg score :' , avg)

if avg>=80:
     print('A')
elif avg>=60:
     print('B')
elif avg>=50:
     print('C')
else:
     print('D')
     
     

