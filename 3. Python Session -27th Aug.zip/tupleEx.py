wdays = ('mon','tue','wed','thu','fri')

day = input('today day :')

if day in wdays:
     print('working days ')
else:
     print('week end')
     
