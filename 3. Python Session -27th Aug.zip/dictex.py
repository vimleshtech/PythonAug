words = {1:'one',2:'two',3:'three' }

d = int(input('enter digit :'))
print(words[d])

#
words = {1:[1,'raman','male',44444],2:'two',3:'three' }

d = int(input('enter digit :'))
print(words[d])
